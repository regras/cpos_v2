from cpos.net import channel

class PeerNetInfo:
    def __init__(self):
        pass

class Peer:
    def __init__(self):
        pass
