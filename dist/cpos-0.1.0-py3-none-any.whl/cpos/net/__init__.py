import zmq
import logging

context = zmq.Context()
logging.getLogger(__name__).addHandler(logging.NullHandler())

logging.warn("Started")
