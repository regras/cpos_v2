# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cpos', 'cpos.net', 'cpos.p2p', 'cpos.protocol']

package_data = \
{'': ['*']}

install_requires = \
['pyzmq>=24.0.1,<25.0.0']

setup_kwargs = {
    'name': 'cpos',
    'version': '0.1.0',
    'description': 'Python implementation of the CPoS protocol',
    'long_description': '# cpos_v2\nA new and refactored version of CPoS.\n',
    'author': 'Vinicius Peixoto',
    'author_email': 'nukelet@protonmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
