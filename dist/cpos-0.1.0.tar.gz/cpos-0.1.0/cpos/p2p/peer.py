class PeerNetInfo:
    def __init__(self):
        self.ip
        pass

class Peer:
    def __init__(self):
        pass
