import logging

class NetInfo:
    def __init__(self, ip: str, port: int):
        self.ip = ip
        self.port = port

class Channel:
    def __init__(self, info: NetInfo):
        self.logger = logging.getLogger(__name__)
        self.logger.warning("Started")

